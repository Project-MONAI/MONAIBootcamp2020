def instance_norm(input: Tensor,
    running_mean: Optional[Tensor]=None,
    running_var: Optional[Tensor]=None,
    weight: Optional[Tensor]=None,
    bias: Optional[Tensor]=None,
    use_input_stats: bool=True,
    momentum: float=0.10000000000000001,
    eps: float=1.0000000000000001e-05) -> Tensor:
  _0 = __torch__.torch.nn.functional._verify_batch_size
  _1 = _0(torch.size(input), )
  _2 = torch.instance_norm(input, weight, bias, running_mean, running_var, use_input_stats, momentum, eps, True)
  return _2
def dropout(input: Tensor,
    p: float=0.5,
    training: bool=True,
    inplace: bool=False) -> Tensor:
  if torch.lt(p, 0.):
    _3 = True
  else:
    _3 = torch.gt(p, 1.)
  if _3:
    ops.prim.RaiseException("Exception")
  else:
    pass
  if inplace:
    _4 = torch.dropout_(input, p, training)
  else:
    _4 = torch.dropout(input, p, training)
  return _4
def prelu(input: Tensor,
    weight: Tensor) -> Tensor:
  return torch.prelu(input, weight)
def linear(input: Tensor,
    weight: Tensor,
    bias: Optional[Tensor]=None) -> Tensor:
  if torch.eq(torch.dim(input), 2):
    _5 = torch.__isnot__(bias, None)
  else:
    _5 = False
  if _5:
    bias0 = unchecked_cast(Tensor, bias)
    ret0 = torch.addmm(bias0, input, torch.t(weight), beta=1, alpha=1)
    ret = ret0
  else:
    output = torch.matmul(input, torch.t(weight))
    if torch.__isnot__(bias, None):
      bias1 = unchecked_cast(Tensor, bias)
      output1 = torch.add_(output, bias1, alpha=1)
      output0 = output1
    else:
      output0 = output
    ret = output0
  return ret
def _verify_batch_size(size: List[int]) -> None:
  size_prods = size[0]
  size_prods0 = size_prods
  for i in range(torch.sub(torch.len(size), 2)):
    size_prods1 = torch.mul(size_prods0, size[torch.add(i, 2)])
    size_prods0 = size_prods1
  if torch.eq(size_prods0, 1):
    ops.prim.RaiseException("Exception")
  else:
    pass
  return None
