class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  layer_0 : __torch__.monai.networks.blocks.convolutions.ResidualUnit
  layer_1 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_8.ResidualUnit
  layer_2 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_15.ResidualUnit
  layer_3 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_22.ResidualUnit
  layer_4 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_29.ResidualUnit
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_30.Sequential,
    input: Tensor) -> Tensor:
    _0 = self.layer_0
    _1 = self.layer_1
    _2 = self.layer_2
    _3 = self.layer_3
    _4 = self.layer_4
    input0 = (_0).forward(input, )
    input1 = (_1).forward(input0, )
    input2 = (_2).forward(input1, )
    input3 = (_3).forward(input2, )
    return (_4).forward(input3, )
