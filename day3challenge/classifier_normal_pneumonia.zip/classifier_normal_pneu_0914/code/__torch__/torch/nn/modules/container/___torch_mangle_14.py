class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  unit0 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_11.Convolution
  unit1 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_13.Convolution
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_14.Sequential,
    input: Tensor) -> Tensor:
    _0 = self.unit0
    _1 = self.unit1
    input0 = (_0).forward(input, )
    return (_1).forward(input0, )
