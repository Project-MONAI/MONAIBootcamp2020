class Reshape(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  shape : Tuple[int, int]
  def forward(self: __torch__.monai.networks.layers.simplelayers.Reshape,
    x: Tensor) -> Tensor:
    _0, _1, = self.shape
    shape = torch.list([_0, _1])
    _2 = torch._set_item(shape, 0, (torch.size(x))[0])
    return torch.reshape(x, shape)
