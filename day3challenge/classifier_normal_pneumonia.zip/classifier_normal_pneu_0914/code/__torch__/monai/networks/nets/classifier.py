class Classifier(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  in_channels : int
  in_shape : List[int]
  dimensions : int
  channels : Tuple[int, int, int, int, int]
  strides : Tuple[int, int, int, int, int]
  out_shape : Tuple[int]
  kernel_size : Tuple[int, int]
  num_res_units : int
  act : str
  norm : str
  dropout : float
  bias : bool
  final_size : Tuple[int, int]
  net : __torch__.torch.nn.modules.container.___torch_mangle_30.Sequential
  reshape : __torch__.monai.networks.layers.simplelayers.Reshape
  final : __torch__.torch.nn.modules.container.___torch_mangle_31.Sequential
  def forward(self: __torch__.monai.networks.nets.classifier.Classifier,
    x: Tensor) -> Tensor:
    x0 = (self.net).forward(x, )
    x1 = (self.final).forward(x0, )
    return (self.reshape).forward(x1, )
