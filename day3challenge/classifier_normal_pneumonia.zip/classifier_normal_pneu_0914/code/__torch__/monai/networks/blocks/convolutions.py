class ResidualUnit(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  dimensions : int
  in_channels : int
  out_channels : int
  conv : __torch__.torch.nn.modules.container.Sequential
  residual : __torch__.torch.nn.modules.conv.Conv2d
  def forward(self: __torch__.monai.networks.blocks.convolutions.ResidualUnit,
    x: Tensor) -> Tensor:
    res = (self.residual).forward(x, )
    cx = (self.conv).forward(x, )
    return torch.add(cx, res, alpha=1)
class Convolution(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  dimensions : int
  in_channels : int
  out_channels : int
  is_transposed : bool
  conv : __torch__.torch.nn.modules.conv.Conv2d
  norm : __torch__.torch.nn.modules.instancenorm.InstanceNorm2d
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  act : __torch__.torch.nn.modules.activation.PReLU
  def forward(self: __torch__.monai.networks.blocks.convolutions.Convolution,
    input: Tensor) -> Tensor:
    _0 = self.conv
    _1 = self.norm
    _2 = self.dropout
    _3 = self.act
    input0 = (_0).forward(input, )
    input1 = (_1).forward(input0, )
    input2 = (_2).forward(input1, )
    return (_3).forward(input2, )
