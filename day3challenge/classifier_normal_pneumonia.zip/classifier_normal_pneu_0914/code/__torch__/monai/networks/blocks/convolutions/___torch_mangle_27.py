class Convolution(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  dimensions : int
  in_channels : int
  out_channels : int
  is_transposed : bool
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_26.Conv2d
  def forward(self: __torch__.monai.networks.blocks.convolutions.___torch_mangle_27.Convolution,
    input: Tensor) -> Tensor:
    return (self.conv).forward(input, )
